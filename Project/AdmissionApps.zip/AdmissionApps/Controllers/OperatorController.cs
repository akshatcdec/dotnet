﻿using Microsoft.AspNetCore.Mvc;

namespace AdmissionApps.Controllers
{
    public class OperatorController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
