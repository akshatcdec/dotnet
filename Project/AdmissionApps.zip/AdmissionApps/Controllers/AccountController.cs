﻿using AdmissionApps.Models;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;

namespace AdmissionApps.Controllers
{
    public class AccountController : Controller
    {
        public IActionResult SignUp()
        {
            return View();
        }
        public IActionResult Login()
        {
            return View();
        }
        public IActionResult AccessDenied()
        {
            return View();
        }
        public async Task<IActionResult> Logout()
        {
            await HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
            return Redirect("/Account/Login");
        }
        [Authorize(Roles = "STUDENT")]
        public IActionResult Dashboard()
        {
            return View();
        }
        [HttpPost]
        public async Task<IActionResult> Login(LoginViewModel viewModel)
        {
            AdmissionDbContext ob = new AdmissionDbContext();
            var user= ob.Users.FirstOrDefault( x=>x.EmailId== viewModel.Email && x.Password== viewModel.Password);
            if (user!=null)
            {
                var claims = new List<Claim>() {
                        new Claim(ClaimTypes.NameIdentifier, Convert.ToString(user.Id)),
                        new Claim(ClaimTypes.Name, user.Name),
                        new Claim(ClaimTypes.Role, user.UserType),
                        new Claim("MobileNo", user.MobileNo)
                };
                //Initialize a new instance of the ClaimsIdentity with the claims and authentication scheme    
                var identity = new ClaimsIdentity(claims, CookieAuthenticationDefaults.AuthenticationScheme);
                //Initialize a new instance of the ClaimsPrincipal with ClaimsIdentity    
                var principal = new ClaimsPrincipal(identity);
                //SignInAsync is a Extension method for Sign in a principal for the specified scheme.    
                await HttpContext.SignInAsync(CookieAuthenticationDefaults.AuthenticationScheme, principal, new AuthenticationProperties());
                return Redirect("/Account/Dashboard");
            }
            else
            {
                ViewData["MSG"] = "Invalid usre Name or password";
                return View(viewModel);
            }

        }
        [HttpPost]
        public IActionResult SignUp(Users user)
        {
            AdmissionDbContext ob = new AdmissionDbContext();

            bool IsMobile = ob.Users.Any(x => x.MobileNo == user.MobileNo);
            bool IsEmail = ob.Users.Any(x => x.EmailId == user.EmailId);
            if (IsMobile)
            {
                ViewData["MSG"] = "Mobile Exist";
                return View(user);
            }
            if (IsEmail)
            {
                ViewData["MSG"] = "Email Exist";
                return View(user);
            }
            user.UserType = "STUDENT";
             ob.Users.Add(user);
            int result= ob.SaveChanges();
            if (result > 0)
            {
                ViewData["MSG"] = "Account Created Please Login";
                ModelState.Clear();
                return View(null);
            }
            else
            {
                ViewData["MSG"] = "Network error";
                return View(user);
            }

        }
    }
}
