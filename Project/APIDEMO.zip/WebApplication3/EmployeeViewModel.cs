﻿namespace WebApplication3
{
    public class EmployeeViewModel
    {
        public int EmpId { get; set; }
        public string EmployeeName { get; set; }
        public string FatherName { get; set; }
        public string MobileNo { get; set; }
    }
}
